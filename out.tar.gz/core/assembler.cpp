#include "./assembler.hpp"

_GXA_::_GXA_(string content, _GXA_config_t config = {})
{
    this->input = content;
    this->config = config;
    if (this->config.register_values.size())
        this->vir_regs = this->config.register_values;
    if (this->config.registers_name.size())
        this->vir_regs_names = this->config.registers_name;
    if (this->config.special_registers_name.size())
        this->special_vir_regs_name = this->config.special_registers_name;
}
void _GXA_::init(string content, _GXA_config_t config = {})
{
    this->input = content;
    this->config = config;
    if (this->config.register_values.size())
        this->vir_regs = this->config.register_values;
    if (this->config.registers_name.size())
        this->vir_regs_names = this->config.registers_name;
    if (this->config.special_registers_name.size())
        this->special_vir_regs_name = this->config.special_registers_name;
}

_GXA_::_GXA_() {}
_GXA_::~_GXA_()
{
    this->status = 3;
    this->runtime_errors.clear();
    this->labels.clear();
    this->input.clear();
    this->startLabel = {};
    this->vir_regs_names.clear();
    this->special_vir_regs_name.clear();
    this->vir_regs.clear();
}

vector<_GXA_external_argument_t> _GXA_::_parse_argular_(string path, uint64_t index)
{
    vector<_GXA_external_argument_t> output;
    fstream extern_f;
    vector<string> lines;
    string line;

    extern_f.open(path, ios::in);

    if (!extern_f.is_open())
    {
        _GXLT_error_t error = {"[runtime]", "Failed to open file in '" + path + "'!", "FILE_READ_FAILURE", "input-output", index};
        this->runtime_errors.push_back(error);
        return output;
    }
    while (getline(extern_f, line))
    {
        lines.push_back(line);
    }

    for (uint32_t i = 0; i < lines.size(); i++)
    {
        for (uint64_t j = 0; j < lines[i].length(); j++)
        {
            if (lines[i][j] == '=')
            {
                const string value = lines[i].substr(j + 1);
                const string name = lines[i].substr(0, j);

                if (!isValidNumber(value))
                {
                    _GXLT_error_t error = {path, "Invalid syntax for" + name + "arguments value!", "INVALID_ARGUMNET_VALUE", "input-output", index};
                    this->runtime_errors.push_back(error);
                    return output;
                }

                _GXA_external_argument_t argument = {value, name};
                output.push_back(argument);
                this->external_arguments.push_back(argument);
            }
        }
    }
    return output;
}

void _GXA_::_open_extern_(string path, string name, uint64_t index)
{
    fstream extern_f;
    string content;
    char ch;

    extern_f.open(path, ios::in);

    if (!extern_f.is_open())
    {
        _GXLT_error_t error = {path, "Failed to open file in '" + path + "'!", "FILE_READ_FAILURE", "input-output", index};
        this->runtime_errors.push_back(error);
        return;
    }
    while (extern_f.read(&ch, 1))
    {
        content += ch;
    }

    _GXA_external_t external = {content, name};
    this->externals.push_back(external);
}

vector<_GXA_label_t> _GXA_::_slice_labels_(string content)
{
    vector<_GXA_label_t> output;
    vector<string> lines = split(content, '\n');
    _GXA_label_t label;

    int idx_line = -1;
    char label_filter[8] = {'\r', '\n', ' ', '\a', '\b', '\t', '\f', ':'};
    char empties[7] = {'\r', '\n', ' ', '\a', '\b', '\t', '\f'};

    for (uint32_t i = 0; i < lines.size(); i++)
    {
        if (!filter(lines[i], empties, 7).length())
            continue;
        const string l = trim(lines[i]);

        if (l.find(":") != string::npos)
        {
            if (label.name.length())
            {
                label.text = label.text.substr(0, label.text.length() - 1);
                output.push_back(label);
                label.name.clear();
                label.text.clear();
                label.line_idx = 0;
            }

            if (filter(l, label_filter, 8).empty())
                continue;
            label.name = filter(l, label_filter, 8);
            label.line_idx = i;
        }
        else if (l == "end")
        {
            label.text = label.text.substr(0, label.text.length() - 1);
            output.push_back(label);
            label.name.clear();
            label.text.clear();
            label.line_idx = 0;
        }
        else if (label.name.length() && trim(lines[i]) != "end")
        {
            label.text += lines[i] + '\n';
        }
    }
    if (label.name.length())
        output.push_back(label);

    return output;
}

void _GXA_::_pre_processors_(string &content, vector<uint32_t> ignore_lines, bool dry)
{
    vector<string> lines = split(content, '\n');
    char empties[7] = {'\r', '\n', ' ', '\a', '\b', '\t', '\f'};

    for (uint32_t i = 0; i < lines.size(); i++)
    {
        if (includes(ignore_lines, i))
            continue;
        if (!filter(lines[i], empties, 7).length())
            continue;
        const vector<string> parts = split(lines[i], ' ');

        if (parts[0] == ".replace")
        {
            content = replaceAll(content, parts[1], parts[2]);
            lines = split(content, '\n');
            lines[i] = "_NONE_";
        }
        else if (parts[0] == ".end")
        {
            lines[i] = "_NONE_";
            string out = "";
            for (string s : lines)
            {
                if (s == "_NONE_")
                    continue;
                out += s + '\n';
            }
            content = out + '\n';
            break;
        }

        else if (parts[0] == ".main")
        {
            this->startLabel.name = parts[1];
            lines[i] = "_NONE_";
        }
        else if (parts[0] == ".argular")
        {
            if (dry)
                continue;
            vector<_GXA_external_argument_t> arguments = this->_parse_argular_(parts[1].substr(parts[1].find_first_of('"') + 1, parts[1].find_last_of('"') - 1), i);
            this->external_arguments.insert(this->external_arguments.end(), arguments.begin(), arguments.end());
        }

        else if (parts[0] == ".extern")
        {
            if (dry)
                continue;
            this->_open_extern_(parts[1].substr(parts[1].find_first_of('"') + 1, parts[1].find_last_of('"') - 1), parts[2], i);
        }
    }
}

vector<_GXA_snippet_t> _GXA_::_transpile_(string content, uint64_t line_idx)
{
    vector<_GXA_snippet_t> output;
    vector<string> lines = split(content, '\n');
    string temp_line;

    long int cmp = 0;
    char empties[7] = {'\t', '\n', '\f', '\r', ' ', '\a', '\v'};

    for (uint32_t i = 0; i < lines.size(); i++)
    {
        if (!filter(lines[i], empties, 7).length())
            continue;

        temp_line = trim(lines[i]);
        const vector<string> parts = split(temp_line, ' ');
        vector<string> params = parts.size() > 1 ? split(join(vector<string>(parts.begin() + 1, parts.end()), " "), ',') : vector<string>();
        const uint32_t lx = i + line_idx;

        if (parts[0] == "mov")
        {
            int tar_reg_idx = -1;

            tar_reg_idx = find(this->vir_regs_names, params[0]);
            if (params[1][0] == '#')
                this->vir_regs[tar_reg_idx] = to_autoNumber(params[1].substr(1));
            else
            {
                int reg2 = find(this->vir_regs_names, params[1]);
                this->vir_regs[tar_reg_idx] = this->vir_regs[reg2];
            }
        }
        else if (parts[0] == "logi")
        {
            int tar_reg_idx = -1;
            logictype_t bin1 = 0;
            logictype_t bin2 = 0;

            bin1 = (logictype_t)this->vir_regs[tar_reg_idx];
            const uint32_t dest_idx = find(this->vir_regs_names, params[0]);

            if (params[1][0] == '#')
                bin1 = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    bin1 = (logictype_t)(this->vir_regs[tar_reg_idx]);
            }
            if (params[2][0] == '#')
                bin2 = to_autoNumber(params[2].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[2]);
                if (tar_reg_idx > -1)
                    bin2 = (logictype_t)(this->vir_regs[tar_reg_idx]);
            }

            if (params[3] == "AND")
                this->vir_regs[dest_idx] = bin1 & bin2;
            else if (params[3] == "ORR")
                this->vir_regs[dest_idx] = bin1 | bin2;
            else if (params[3] == "XOR")
                this->vir_regs[dest_idx] = bin1 ^ bin2;
            else if (params[3] == "NOR")
                this->vir_regs[dest_idx] = ~(bin1 | bin2);
            else if (params[3] == "NAND")
                this->vir_regs[dest_idx] = ~(bin1 & bin2);
            else if (params[3] == "NXOR")
                this->vir_regs[dest_idx] = (bin1 ^ bin2);
            else if (params[3] == "NOT")
                this->vir_regs[dest_idx] = ~bin1;
        }
        else if (parts[0] == "shif")
        {
            int tar_reg_idx = -1;
            logictype_t val;
            logictype_t amount;

            tar_reg_idx = find(this->vir_regs_names, params[0]);
            val = this->vir_regs[tar_reg_idx];
            if (params[1].size())
            {
                if (params[1][0] == '#')
                    amount = to_autoNumber(trim(params[1].substr(1)));
                else
                {
                    tar_reg_idx = find(this->vir_regs_names, params[1]);
                    amount = (logictype_t)this->vir_regs[tar_reg_idx];
                }
            }
            tar_reg_idx = find(this->vir_regs_names, params[0]);
            if (params[2] == "LEFT")
                this->vir_regs[tar_reg_idx] = val << amount;
            else
                this->vir_regs[tar_reg_idx] = val >> amount;
        }
        else if (parts[0] == "cmp")
        {
            long int reg1_idx = find(this->vir_regs_names, params[0]);
            ;
            long int reg2_idx;
            if (params[1][0] == '#')
            {
                reg2_idx = to_autoNumber(params[1]);
                cmp = reg1_idx - reg2_idx;
            }
            else
            {
                reg2_idx = find(this->vir_regs_names, params[1]);
                cmp = this->vir_regs[reg1_idx] - this->vir_regs[reg2_idx];
            }
        }
        else if (parts[0] == "add")
        {
            int reg_dest_idx = 0;
            logictype_t reg1 = find(this->vir_regs_names, params[0]);
            logictype_t reg2 = 0;

            if (params[1][0] == '#')
                reg1 = to_autoNumber(params[1].substr(1));
            else
                reg1 = this->vir_regs[find(this->vir_regs_names, params[1])];

            if (params[2][0] == '#')
                reg2 = to_autoNumber(params[2].substr(1));
            else
                reg2 = this->vir_regs[find(this->vir_regs_names, params[2])];

            if (reg1 > -1)
                this->vir_regs[reg_dest_idx] = reg1 + reg2;
        }
        else if (parts[0] == "mul")
        {
            int reg_dest_idx = 0;
            logictype_t reg1 = find(this->vir_regs_names, params[0]);
            logictype_t reg2 = 0;

            if (params[1][0] == '#')
                reg1 = to_autoNumber(params[1].substr(1));
            else
                reg1 = this->vir_regs[find(this->vir_regs_names, params[1])];

            if (params[2][0] == '#')
                reg2 = to_autoNumber(params[2].substr(1));
            else
                reg2 = this->vir_regs[find(this->vir_regs_names, params[2])];

            if (reg1 > -1)
                this->vir_regs[reg_dest_idx] = reg1 * reg2;
        }
        else if (parts[0] == "div")
        {
            int reg_dest_idx = 0;
            logictype_t reg1 = find(this->vir_regs_names, params[0]);
            logictype_t reg2 = 0;

            if (params[1][0] == '#')
                reg1 = to_autoNumber(params[1].substr(1));
            else
                reg1 = this->vir_regs[find(this->vir_regs_names, params[1])];

            if (params[2][0] == '#')
                reg2 = to_autoNumber(params[2].substr(1));
            else
                reg2 = this->vir_regs[find(this->vir_regs_names, params[2])];

            if (reg1 > -1)
                this->vir_regs[reg_dest_idx] = reg1 / reg2;
        }
        else if (parts[0] == "sub")
        {
            int reg_dest_idx = 0;
            logictype_t reg1 = find(this->vir_regs_names, params[0]);
            logictype_t reg2 = 0;

            if (params[1][0] == '#')
                reg1 = to_autoNumber(params[1].substr(1));
            else
                reg1 = this->vir_regs[find(this->vir_regs_names, params[1])];

            if (params[2][0] == '#')
                reg2 = to_autoNumber(params[2].substr(1));
            else
                reg2 = this->vir_regs[find(this->vir_regs_names, params[2])];

            if (reg1 > -1)
                this->vir_regs[reg_dest_idx] = reg1 - reg2;
        }
        else if (parts[0] == "pow")
        {
            int reg_dest_idx = 0;
            logictype_t reg1 = find(this->vir_regs_names, params[0]);
            logictype_t reg2 = 0;

            if (params[1][0] == '#')
                reg1 = to_autoNumber(params[1].substr(1));
            else
                reg1 = this->vir_regs[find(this->vir_regs_names, params[1])];

            if (params[2][0] == '#')
                reg2 = to_autoNumber(params[2].substr(1));
            else
                reg2 = this->vir_regs[find(this->vir_regs_names, params[2])];

            if (reg1 > -1)
                this->vir_regs[reg_dest_idx] = pow(reg1, reg2);
        }
        else if (parts[0] == "incr")
        {
            int reg_idx = find(this->vir_regs_names, params[0]);
            if (reg_idx > -1)
                this->vir_regs[reg_idx]++;
        }

        else if (parts[0] == "sqrt")
        {
            int reg_dest_idx = 0;
            logictype_t reg1 = find(this->vir_regs_names, params[0]);

            if (params[1][0] == '#')
                reg1 = to_autoNumber(params[1].substr(1));
            else
                reg1 = this->vir_regs[find(this->vir_regs_names, params[1])];

            if (reg1 > -1)
                this->vir_regs[reg_dest_idx] = sqrt(reg1);
        }

        else if (parts[0] == "decr")
        {
            int reg_idx = find(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx]--;
        }
        else if (parts[0] == "push")
        {
            if (params[0][0] == '#')
                this->vir_stack.push_back(to_autoNumber(params[0]));
            else
            {
                const int reg = find(this->vir_regs_names, params[0]);
                this->vir_stack.push_back(this->vir_regs[reg]);
            }
        }
        else if (parts[0] == "pull")
        {
            const uint16_t reg = find(this->vir_regs_names, params[0]);
            this->vir_regs[reg] = this->vir_stack[this->vir_stack.size() - 1];
            this->vir_stack = vector<logictype_t>(this->vir_stack.begin(), this->vir_stack.end() - 1);
        }

        else if (parts[0] == "exint")
        {
            string target_content;
            const string name = params[1].substr(params[1].find_first_of('"') + 1, params[1].find_last_of('"') - 1);
            bool found = false;

            for (_GXA_external_t ext : this->externals)
            {
                if (trim(ext.name) == name)
                {
                    found = true;
                    const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
                    this->vir_regs[reg_idx] = to_autoNumber(filter(ext.content, '\n'));
                    break;
                }
            }
            if (!found)
            {
                _GXLT_error_t error = {"[runtime]", "invalid external refrenced '" + params[1] + "'!", "INVALID_EXTERNAL_REFRENCED", "syntax", line_idx + i};
                this->runtime_errors.push_back(error);
                continue;
            }
        }
        else if (parts[0] == "argint")
        {
            _GXA_external_argument_t target_argument;
            const string name = params[1].substr(params[1].find_first_of('"') + 1, params[1].find_last_of('"') - 1);
            bool found = false;

            for (_GXA_external_argument_t arg : this->external_arguments)
            {
                if (arg.name == name)
                {
                    const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
                    this->vir_regs[reg_idx] = to_autoNumber(trim(arg.value));
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                _GXLT_error_t error = {"[runtime]", "invalid external argument refrenced '" + params[1] + "'!", "INVALID_EXTERNAL_ARGUMENT_REFRENCED", "syntax", line_idx + i};
                this->runtime_errors.push_back(error);
                continue;
            }
        }
        else if (parts[0] == "abs")
        {
            int tar_reg_idx = -1;
            logictype_t val = 0;
            if (params[1][0] == '#')
                val = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    val = this->vir_regs[tar_reg_idx];
            }

            const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx] = (logictype_t)abs(val);
        }
        else if (parts[0] == "ceil")
        {

            int tar_reg_idx = -1;
            logictype_t val = 0;
            if (params[1][0] == '#')
                val = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    val = this->vir_regs[tar_reg_idx];
            }

            const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx] = (logictype_t)ceil(val);
        }
        else if (parts[0] == "flr")
        {
            int tar_reg_idx = -1;
            logictype_t val = 0;
            if (params[1][0] == '#')
                val = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    val = this->vir_regs[tar_reg_idx];
            }

            const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx] = (logictype_t)floor(val);
        }
        else if (parts[0] == "rnd")
        {

            int tar_reg_idx = -1;
            logictype_t val = 0;
            if (params[1][0] == '#')
                val = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    val = this->vir_regs[tar_reg_idx];
            }

            const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx] = (logictype_t)round(val);
        }
        else if (parts[0] == "tan")
        {

            int tar_reg_idx = -1;
            logictype_t val = 0;
            if (params[1][0] == '#')
                val = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    val = this->vir_regs[tar_reg_idx];
            }

            const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx] = (logictype_t)tan(val);
        }
        else if (parts[0] == "sin")
        {
            int tar_reg_idx = -1;
            logictype_t val = 0;
            if (params[1][0] == '#')
                val = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    val = this->vir_regs[tar_reg_idx];
            }

            const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx] = (logictype_t)sin(val);
        }
        else if (parts[0] == "cos")
        {

            int tar_reg_idx = -1;
            logictype_t val = 0;
            if (params[1][0] == '#')
                val = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    val = this->vir_regs[tar_reg_idx];
            }

            const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx] = (logictype_t)cos(val);
        }
        else if (parts[0] == "cosh")
        {

            int tar_reg_idx = -1;
            logictype_t val = 0;
            if (params[1][0] == '#')
                val = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    val = this->vir_regs[tar_reg_idx];
            }

            const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx] = (logictype_t)cosh(val);
        }
        else if (parts[0] == "sinh")
        {

            int tar_reg_idx = -1;
            logictype_t val = 0;
            if (params[1][0] == '#')
                val = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    val = this->vir_regs[tar_reg_idx];
            }

            const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx] = (logictype_t)sin(val);
        }
        else if (parts[0] == "tanh")
        {

            int tar_reg_idx = -1;
            logictype_t val = 0;
            if (params[1][0] == '#')
                val = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    val = this->vir_regs[tar_reg_idx];
            }

            const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx] = (logictype_t)tanh(val);
        }
        else if (parts[0] == "ln")
        {

            int tar_reg_idx = -1;
            logictype_t val = 0;
            if (params[1][0] == '#')
                val = to_autoNumber(params[1].substr(1));
            else
            {
                tar_reg_idx = find(this->vir_regs_names, params[1]);
                if (tar_reg_idx > -1)
                    val = this->vir_regs[tar_reg_idx];
            }

            const uint16_t reg_idx = find<string>(this->vir_regs_names, params[0]);
            this->vir_regs[reg_idx] = (logictype_t)log(val);
        }
        else if (parts[0] == "call")
        {
            _GXA_label_t target_label;
            for (uint32_t i = 0; i < this->labels.size(); i++)
            {
                if (this->labels[i].name == params[0])
                    target_label = this->labels[i];
            }

            if (params.size() == 2)
            {
                if (params[1] == "EQ" && cmp != 0)
                    continue;
                else if (params[1] == "LE" && cmp >= 0)
                    continue;
                else if (params[1] == "GE" && cmp <= 0)
                    continue;
                else if (params[1] == "NE" && !cmp)
                    continue;
            }

            const vector<_GXA_snippet_t> call_out = this->_transpile_(target_label.text, target_label.line_idx);
            output.insert(output.end(), call_out.begin(), call_out.end());
        }
        else if (parts[0] == "jmp")
        {
            _GXA_label_t target_label;
            for (uint32_t i = 0; i < this->labels.size(); i++)
            {
                if (this->labels[i].name == params[0])
                    target_label = this->labels[i];
            }

            if (params.size() == 2)
            {
                if (params[1] == "EQ" && cmp != 0)
                    continue;
                else if (params[1] == "LE" && cmp >= 0)
                    continue;
                else if (params[1] == "GE" && cmp <= 0)
                    continue;
                else if (params[1] == "NE" && !cmp)
                    continue;
            }

            const vector<_GXA_snippet_t> call_out = this->_transpile_(target_label.text, target_label.line_idx);
            output.insert(output.end(), call_out.begin(), call_out.end());
            break;
        }
        else if (parts[0] == "transpile")
        {
            _GXA_snippet_t snippet;
            for (string s : this->special_vir_regs_name)
            {
                const int idx = find<string>(this->vir_regs_names, s);
                snippet.push_back(this->vir_regs[idx]);
            }
            output.push_back(snippet);
        }
        else if (parts[0] == "reset")
        {
            if (parts[1] == "general")
            {
                for (uint32_t j = 0; j < this->vir_regs.size(); j++)
                {
                    bool skip = false;
                    for (uint32_t k = 0; k < this->special_vir_regs_name.size(); k++)
                    {
                        if (this->vir_regs_names[j] == this->special_vir_regs_name[k])
                        {
                            skip = true;
                            break;
                        }
                        if (skip)
                            continue;
                        this->vir_regs[j] = 0;
                    }
                }
            }
            else if (parts[1] == "specials")
            {
                for (uint32_t j = 0; j < this->vir_regs.size(); j++)
                {
                    for (uint32_t k = 0; k < this->special_vir_regs_name.size(); k++)
                    {
                        if (this->vir_regs_names[j] == this->special_vir_regs_name[k])
                        {
                            this->vir_regs[j] = 0;
                            break;
                        }
                    }
                }
            }
            else if (parts[1] == "all")
            {
                for (uint32_t j = 0; j < this->vir_regs.size(); j++)
                {
                    this->vir_regs[j] = 0;
                }
            }
            else if (parts[1] == "stack")
            {
                this->vir_stack = vector<logictype_t>();
            }
        }
        else if (parts[0] == "debug")
        {
            string text = lines[i].substr(lines[i].find('('), lines[i].find(')') - 1);
            cout << "[debug, line " << (line_idx + i + 1) << "]: " << text << "\n";
        }
    }

    return output;
}

vector<_GXA_snippet_t> _GXA_::compile()
{
    const vector<string> lines = split(this->input, '\n');

    const vector<_GXA_label_t> labels = this->_slice_labels_(this->input);
    this->labels = labels;
    this->_pre_processors_(this->input, vector<uint32_t>(), true);

    for (uint32_t i = 0; i < this->labels.size(); i++)
    {
        if (this->startLabel.name == this->labels[i].name)
        {
            this->startLabel = this->labels[i];
        }
    }

    this->output = this->_transpile_(this->startLabel.text, this->startLabel.line_idx);

    return this->output;
}
